<?php
/**
 * Automatic rider assignment.
 *
 * A new order (status Pending, no rider yet) is offered to ONE rider at a time: an approved rider who is online right now
 * (app checked in recently) and holds no other order (nothing offered, nothing being delivered). The rider gets a notification and
 * accepts or rejects in the rider app (accepting confirms the order). An offer nobody answers within AA_OFFER_TTL seconds, or a
 * rejection, moves the order to the next free rider. With nobody free the order simply waits and is offered again as soon as a rider
 * comes online or finishes a delivery. Admin can still assign / unassign by hand; unassigning puts the order on hold (no auto offers).
 * Switch off with kv auto_assign = '0'.
 */
const AA_OFFER_TTL = 90;     // seconds a rider has to answer an offer
const AA_SKIP_TTL = 300;     // a rider who rejected / missed an offer is skipped for this order for this long
const AA_BUSY = "'assigned','accepted','going','picked','ontheway','arrived'";

function aa_enabled() { $r = kv_get('auto_assign'); return !$r || (string)$r['v'] !== '0'; }
function aa_tried($oid) { $r = kv_get('aa_tried:' . $oid); $a = $r ? json_decode($r['v'], true) : null; return is_array($a) ? $a : []; }
function aa_mark_tried($oid, $rid) {
    $a = aa_tried($oid); $t = now_ts();
    foreach ($a as $k => $ts) if ($ts < $t - AA_SKIP_TTL) unset($a[$k]);
    $a[(string)(int)$rid] = $t;
    kv_set('aa_tried:' . $oid, json_encode($a));
}
function aa_hold($oid) { $r = kv_get('aa_hold:' . $oid); return $r && $r['v'] === '1'; }

/** The free rider who has been idle longest, or null. $skip = rider ids to leave out. */
function aa_pick_rider($skip = []) {
    $min = now_ts() - 180;
    $rows = db_rows("SELECT r.id, COALESCE((SELECT MAX(d.updated_at) FROM deliveries d WHERE d.rider_id=r.id), 0) AS idle_since
                     FROM riders r
                     WHERE r.status='approved' AND r.online=1 AND r.last_seen IS NOT NULL AND r.last_seen>=?
                       AND NOT EXISTS (SELECT 1 FROM deliveries d2 WHERE d2.rider_id=r.id AND d2.rstat IN (" . AA_BUSY . "))
                     ORDER BY idle_since ASC, r.id ASC", [$min]);
    foreach ($rows as $r) if (!in_array((int)$r['id'], $skip, true)) return (int)$r['id'];
    return null;
}

/** Offers one waiting order to a free rider. Returns the rider id or null. */
function aa_offer($oid) {
    if (!aa_enabled() || aa_hold($oid)) return null;
    return db_tx(function () use ($oid) {
        $o = db_row('SELECT * FROM orders WHERE id=?' . lock_suffix(), [$oid]);
        if (!$o || $o['status'] !== 'Pending') return null;
        $d = db_row('SELECT * FROM deliveries WHERE order_id=?' . lock_suffix(), [$oid]);
        if ($d && !in_array($d['rstat'], ['rejected', 'cancelled', 'failed'], true)) return null;   // someone already has it
        $t = now_ts();
        $skip = [];
        foreach (aa_tried($oid) as $rid => $ts) if ($ts >= $t - AA_SKIP_TTL) $skip[] = (int)$rid;
        $rid = aa_pick_rider($skip);
        if ($rid === null) return null;
        $otp = ($d && !empty($d['otp'])) ? $d['otp'] : str_pad((string)random_int(0, 9999), 4, '0', STR_PAD_LEFT);
        if ($d) q('UPDATE deliveries SET rider_id=?, rstat=?, otp=?, fail_reason=NULL, assigned_at=?, updated_at=? WHERE order_id=?', [$rid, 'assigned', $otp, $t, $t, $oid]);
        else q('INSERT INTO deliveries (order_id, rider_id, rstat, otp, assigned_at, updated_at) VALUES (?,?,?,?,?,?)', [$oid, $rid, 'assigned', $otp, $t, $t]);
        kv_set('aa_auto:' . $oid, (string)$t);
        rider_notify($rid, 'New delivery - please accept', 'Order ' . $oid . ' - ' . $o['name'] . ($o['shop'] ? ' (pickup: ' . $o['shop'] . ')' : '') . '. Open the app and accept within ' . AA_OFFER_TTL . ' seconds.',
                     ['url' => '/#/order/' . rawurlencode($oid), 'kind' => 'order', 'dkey' => 'as:' . $oid . ':' . $t]);
        return $rid;
    });
}

/** Offers that were never answered go back into the queue (only offers made by the auto-assigner, never admin's). */
function aa_expire_offers() {
    $t = now_ts();
    foreach (db_rows("SELECT order_id, rider_id, assigned_at FROM deliveries WHERE rstat='assigned' AND assigned_at<?", [$t - AA_OFFER_TTL]) as $d) {
        $a = kv_get('aa_auto:' . $d['order_id']);
        if (!$a || (int)$a['v'] !== (int)$d['assigned_at']) continue;   // assigned by admin: leave it alone
        db_tx(function () use ($d) {
            $x = db_row("SELECT * FROM deliveries WHERE order_id=? AND rstat='assigned' AND assigned_at=?" . lock_suffix(), [$d['order_id'], $d['assigned_at']]);
            if (!$x) return;
            q('DELETE FROM deliveries WHERE order_id=?', [$d['order_id']]);
            aa_mark_tried($d['order_id'], $d['rider_id']);
            rider_notify($d['rider_id'], 'Offer expired', 'Order ' . $d['order_id'] . ' was offered to the next rider.');
        });
    }
}

/** Offers every waiting order. Cheap when there is nothing to do; $force skips the 8-second throttle. */
function aa_sweep($force = false) {
    try {
        if (!aa_enabled()) return;
        $t = now_ts();
        $last = kv_get('aa_sweep');
        if (!$force && $last && (int)$last['v'] > $t - 8) return;
        kv_set('aa_sweep', (string)$t);
        aa_expire_offers();
        $ids = db_rows("SELECT o.id FROM orders o LEFT JOIN deliveries d ON d.order_id=o.id
                        WHERE o.status='Pending' AND (d.order_id IS NULL OR d.rstat IN ('rejected','cancelled','failed')) ORDER BY o.created_at ASC LIMIT 20");
        foreach ($ids as $r) { if (aa_pick_rider() === null) break; aa_offer($r['id']); }
    } catch (Throwable $e) { error_log('NurBuy auto-assign: ' . $e->getMessage()); }
}

/** A single order just placed / just rejected: offer it right away. Never throws. */
function aa_try($oid) {
    try { if (aa_offer($oid) === null) return; } catch (Throwable $e) { error_log('NurBuy auto-assign: ' . $e->getMessage()); }
}
